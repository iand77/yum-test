
# XXX Grid Assignment

_If your not viewing this via github you can copy and paste the contents of this file into https://stackedit.io/app to render the markdown._

**Client**
XXX

**Developer**
Ian de Almeida

## Usage Instructions

Open index.html in Web Browser preferably Chrome.

## Files

- *index.html* - File to open in web browser. Contains HTML layout and inline JS to render the Grid Component
- *js/main.js* - Vanilla JS to create Grid Component
- *styles/scss/main.scss* - SCSS styling
- *styles/css/main.css* - Transpiled CSS